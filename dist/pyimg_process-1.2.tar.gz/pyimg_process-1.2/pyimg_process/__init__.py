from pyimg_process.Methods import Methods
